export const environment = {
  production: true,
  googleAPIKey: 'AIzaSyDhOyyDOMf4-1mmL8ftPet84ircK11B6GM'
};
