import { StatusFilterPipe } from './status-filter.pipe';

describe('StatusFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new StatusFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
