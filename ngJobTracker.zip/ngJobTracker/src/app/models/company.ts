import { Address } from './address';

export class Company {
  id: number;
  name: string;
  url: string;
  address: Address;

  constructor() {
  }
}
