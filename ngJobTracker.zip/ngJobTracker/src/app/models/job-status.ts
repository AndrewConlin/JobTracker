export class JobStatus {
  id: number;
  status: string;
}
