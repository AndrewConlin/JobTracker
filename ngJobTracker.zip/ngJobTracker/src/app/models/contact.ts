export class Contact {
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  position: string;
  email: string;
  description: string;
}
