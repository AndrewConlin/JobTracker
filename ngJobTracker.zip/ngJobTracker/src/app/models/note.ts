export class Note {
  id: number;
  content: string;
  createDate: Date;
}
